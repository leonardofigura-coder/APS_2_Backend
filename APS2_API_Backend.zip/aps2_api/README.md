# APS 2 - API de Eventos Acadêmicos

API RESTful desenvolvida em Python com FastAPI, Pydantic, JSON e arquitetura MVC.

## Funcionalidades

- CRUD de eventos
- CRUD de participantes
- Inscrição de participante em evento
- Consulta de inscritos
- Validação de dados
- Tratamento de erros
- Swagger/OpenAPI
- Armazenamento em memória

## Estrutura

```text
aps2_api/
├── main.py
├── requirements.txt
├── README.md
├── controller/
│   ├── __init__.py
│   ├── evento_controller.py
│   └── participante_controller.py
├── model/
│   ├── __init__.py
│   ├── evento.py
│   └── participante.py
└── service/
    ├── __init__.py
    ├── evento_service.py
    └── participante_service.py
```

## Instalação

```bash
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
```

## Execução

```bash
uvicorn main:app --reload
```

Acesse:
- API: http://127.0.0.1:8000
- Swagger: http://127.0.0.1:8000/docs

## Principais rotas

### Eventos
- POST /eventos
- GET /eventos
- GET /eventos/{id}
- PUT /eventos/{id}
- DELETE /eventos/{id}

### Participantes
- POST /participantes
- GET /participantes
- GET /participantes/{id}
- PUT /participantes/{id}
- DELETE /participantes/{id}

### Inscrições
- POST /eventos/{evento_id}/inscricoes/{participante_id}
- GET /eventos/{evento_id}/inscricoes

## Exemplo de evento

```json
{
  "titulo": "Workshop de Python",
  "descricao": "Introdução ao Python e FastAPI",
  "data": "2026-10-15",
  "horario": "19:00",
  "local": "Laboratório 01",
  "capacidade": 30,
  "categoria": "Workshop"
}
```

## Exemplo de participante

```json
{
  "nome": "Maria Silva",
  "email": "maria@email.com",
  "curso": "Análise e Desenvolvimento de Sistemas"
}
```

## Exemplos de resposta

### Cadastrar evento (POST /eventos) - 201

```json
{
  "titulo": "Workshop de Python",
  "descricao": "Introdução ao Python e FastAPI",
  "data": "2026-10-15",
  "horario": "19:00:00",
  "local": "Laboratório 01",
  "capacidade": 30,
  "categoria": "Workshop",
  "id": 1
}
```

### Inscrever participante (POST /eventos/1/inscricoes/1) - 201

```json
{
  "evento_id": 1,
  "participante_id": 1
}
```

### Listar inscritos (GET /eventos/1/inscricoes) - 200

```json
[
  {
    "nome": "Maria Silva",
    "email": "maria@email.com",
    "curso": "Análise e Desenvolvimento de Sistemas",
    "id": 1
  }
]
```

## Exemplos de erro

### Evento inexistente - 404

```json
{ "detail": "Evento não encontrado." }
```

### Participante já inscrito - 400

```json
{ "detail": "Participante já está inscrito neste evento." }
```

### Evento sem vagas - 400

```json
{ "detail": "Não existem vagas disponíveis para este evento." }
```

### Dados inválidos (ex.: capacidade 0 ou título só com espaços) - 422

O FastAPI/Pydantic retorna a lista de campos inválidos em `detail`.

## Regras de negócio

- Ao inscrever, a API verifica: evento existe, participante existe, participante ainda não inscrito e evento com vagas.
- Ao excluir um evento ou participante, as inscrições relacionadas também são removidas.
- Não é possível reduzir a capacidade de um evento abaixo do número de inscritos.

## Códigos HTTP utilizados

- 200 OK
- 201 Created
- 204 No Content
- 400 Bad Request
- 404 Not Found
- 422 Unprocessable Entity

## Repositório

- (adicionar o link do GitHub)
