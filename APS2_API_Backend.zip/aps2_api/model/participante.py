from pydantic import BaseModel, Field, EmailStr, field_validator

class ParticipanteBase(BaseModel):
    nome: str = Field(..., min_length=1)
    email: EmailStr
    curso: str = Field(..., min_length=1)

    @field_validator("nome", "curso")
    @classmethod
    def nao_pode_ser_vazio(cls, valor):
        valor = valor.strip()
        if valor == "":
            raise ValueError("O campo não pode ser vazio.")
        return valor

class Participante(ParticipanteBase):
    id: int
