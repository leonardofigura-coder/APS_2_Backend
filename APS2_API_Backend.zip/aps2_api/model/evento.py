from pydantic import BaseModel, Field, field_validator
from datetime import date, time
from enum import Enum

class CategoriaEvento(str, Enum):
    PALESTRA = "Palestra"
    WORKSHOP = "Workshop"
    MINICURSO = "Minicurso"
    SEMINARIO = "Seminário"
    COMPETICAO = "Competição"

class EventoBase(BaseModel):
    titulo: str = Field(..., min_length=1)
    descricao: str = Field(..., min_length=1)
    data: date
    horario: time
    local: str = Field(..., min_length=1)
    capacidade: int = Field(..., gt=0)
    categoria: CategoriaEvento

    @field_validator("titulo", "descricao", "local")
    @classmethod
    def nao_pode_ser_vazio(cls, valor):
        valor = valor.strip()
        if valor == "":
            raise ValueError("O campo não pode ser vazio.")
        return valor

class Evento(EventoBase):
    id: int
