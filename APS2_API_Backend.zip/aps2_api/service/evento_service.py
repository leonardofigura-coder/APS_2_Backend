from fastapi import HTTPException
from model.evento import Evento, EventoBase
from service import participante_service

eventos = []
inscricoes = []
proximo_id_evento = 1

def criar_evento(dados: EventoBase):
    global proximo_id_evento
    evento = Evento(id=proximo_id_evento, **dados.model_dump())
    eventos.append(evento)
    proximo_id_evento += 1
    return evento

def listar_eventos():
    return eventos

def buscar_evento(evento_id: int):
    for evento in eventos:
        if evento.id == evento_id:
            return evento
    raise HTTPException(status_code=404, detail="Evento não encontrado.")

def atualizar_evento(evento_id: int, dados: EventoBase):
    evento = buscar_evento(evento_id)
    quantidade = sum(1 for i in inscricoes if i["evento_id"] == evento_id)
    if dados.capacidade < quantidade:
        raise HTTPException(status_code=400, detail="A nova capacidade é menor que o número de participantes já inscritos.")
    evento.titulo = dados.titulo
    evento.descricao = dados.descricao
    evento.data = dados.data
    evento.horario = dados.horario
    evento.local = dados.local
    evento.capacidade = dados.capacidade
    evento.categoria = dados.categoria
    return evento

def excluir_evento(evento_id: int):
    evento = buscar_evento(evento_id)
    eventos.remove(evento)
    inscricoes[:] = [i for i in inscricoes if i["evento_id"] != evento_id]

def realizar_inscricao(evento_id: int, participante_id: int):
    evento = buscar_evento(evento_id)
    participante_service.buscar_participante(participante_id)
    for inscricao in inscricoes:
        if inscricao["evento_id"] == evento_id and inscricao["participante_id"] == participante_id:
            raise HTTPException(status_code=400, detail="Participante já está inscrito neste evento.")
    quantidade = sum(1 for i in inscricoes if i["evento_id"] == evento_id)
    if quantidade >= evento.capacidade:
        raise HTTPException(status_code=400, detail="Não existem vagas disponíveis para este evento.")
    inscricao = {"evento_id": evento_id, "participante_id": participante_id}
    inscricoes.append(inscricao)
    return inscricao

def listar_inscritos(evento_id: int):
    buscar_evento(evento_id)
    resultado = []
    for inscricao in inscricoes:
        if inscricao["evento_id"] == evento_id:
            resultado.append(participante_service.buscar_participante(inscricao["participante_id"]))
    return resultado

def remover_inscricoes_do_participante(participante_id: int):
    inscricoes[:] = [i for i in inscricoes if i["participante_id"] != participante_id]
