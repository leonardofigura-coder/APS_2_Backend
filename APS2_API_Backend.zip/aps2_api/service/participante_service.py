from fastapi import HTTPException
from model.participante import Participante, ParticipanteBase

participantes = []
proximo_id_participante = 1

def criar_participante(dados: ParticipanteBase):
    global proximo_id_participante
    participante = Participante(id=proximo_id_participante, **dados.model_dump())
    participantes.append(participante)
    proximo_id_participante += 1
    return participante

def listar_participantes():
    return participantes

def buscar_participante(participante_id: int):
    for participante in participantes:
        if participante.id == participante_id:
            return participante
    raise HTTPException(status_code=404, detail="Participante não encontrado.")

def atualizar_participante(participante_id: int, dados: ParticipanteBase):
    participante = buscar_participante(participante_id)
    participante.nome = dados.nome
    participante.email = dados.email
    participante.curso = dados.curso
    return participante

def excluir_participante(participante_id: int):
    from service import evento_service  # import aqui para evitar import circular
    participante = buscar_participante(participante_id)
    participantes.remove(participante)
    evento_service.remover_inscricoes_do_participante(participante_id)
